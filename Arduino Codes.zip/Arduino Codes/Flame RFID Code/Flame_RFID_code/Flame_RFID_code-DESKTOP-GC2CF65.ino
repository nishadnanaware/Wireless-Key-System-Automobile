#include "SPI.h"
#include "MFRC522.h"

#define SS_PIN 10
#define RST_PIN 9

int buzzerPin = 2;
int flamePin = 3;
int Flame = HIGH;
int ONOFFled = 8;

MFRC522 rfid(SS_PIN, RST_PIN);
MFRC522::MIFARE_Key key;

int j=0;

String RFIDKey1 = "D3:83:9D:00"; //assign accepted RFID Tag 1 
String RFIDKey2 = "95:1E:C8:73"; //assign accepted RFID Tag 2

void setup() {
  Serial.begin(9600);
  SPI.begin();
  rfid.PCD_Init();
  pinMode(ONOFFled, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(flamePin, INPUT);

}

void loop() {
  {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial())
    return;

  // Serial.print(F("PICC type: "));
  MFRC522::PICC_Type piccType = rfid.PICC_GetType(rfid.uid.sak);
  // Serial.println(rfid.PICC_GetTypeName(piccType));

  // Check is the PICC of Classic MIFARE type
  if (piccType != MFRC522::PICC_TYPE_MIFARE_MINI &&
    piccType != MFRC522::PICC_TYPE_MIFARE_1K &&
    piccType != MFRC522::PICC_TYPE_MIFARE_4K) {
    Serial.println(F("Your tag is not of type MIFARE Classic."));
    return;
  }

  String strID = "";
  for (byte i = 0; i < 4; i++) {
    strID +=
    (rfid.uid.uidByte[i] < 0x10 ? "0" : "") +
    String(rfid.uid.uidByte[i], HEX) +
    (i!=3 ? ":" : "");
  }
  strID.toUpperCase();

  Serial.print("Tap card key: ");
  Serial.println(strID);

  //check RFID keys
  if(strID.indexOf(RFIDKey1)>=0 or strID.indexOf(RFIDKey2)>=0){
    
    if(j==2){j=0;}
    if(j==0){
      digitalWrite(ONOFFled, HIGH);
    
      }

    if(j==1){
    
      digitalWrite(ONOFFled, LOW);
      }  
      j++;
    }
    else{

      digitalWrite(ONOFFled, LOW);
    }

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}
{
  
  Flame = digitalRead(flamePin);
  if (Flame == LOW)
  {
    digitalWrite(buzzerPin, HIGH);
  }
  else
  {
    digitalWrite(buzzerPin, LOW);

  }
}
}
