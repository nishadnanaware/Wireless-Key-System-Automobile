//BlueetoothApp//
const int LED1 = 10; // Pin for LED1
const int LED2 = 11; // Pin for LED2
const int LED3 = 12; // Pin for LED3
const int LED4 = 13; // Pin for LED4

void setup() {
  Serial.begin(9600); // Start serial communication
  pinMode(LED1, OUTPUT); // Set LED1 as an output
  pinMode(LED2, OUTPUT); // Set LED2 as an output
  pinMode(LED3, OUTPUT); // Set LED3 as an output
  pinMode(LED4, OUTPUT); // Set LED4 as an output


}

void loop() {
  if (Serial.available() > 0) { // Check if data is available
    char data = Serial.read(); // Read the incoming data
    if (data == '1') { // If data is '1', turn on the LEDs
      digitalWrite(LED1, HIGH);
    } 
    else if (data == '0') { // If data is '0', turn off the LEDs
      digitalWrite(LED1, LOW);
    }

  if (data == '3') { // If data is '1', turn on the LEDs
      digitalWrite(LED2, HIGH);
    }
    else if (data == '2') { // If data is '0', turn off the LEDs
      digitalWrite(LED2, LOW);
    }

  if (data == '5') { // If data is '1', turn on the LEDs
      digitalWrite(LED3, HIGH);
    }
    else if (data == '4') { // If data is '0', turn off the LEDs
      digitalWrite(LED3, LOW);
    }

  if (data == '7') { // If data is '1', turn on the LEDs
      digitalWrite(LED4, HIGH);

    } else if (data == '6') { // If data is '0', turn off the LED
      digitalWrite(LED4, LOW);
    }
  }
}