#include "SPI.h"
#include "MFRC522.h"

#define SS_PIN 10
#define RST_PIN 9

MFRC522 rfid(SS_PIN, RST_PIN);
MFRC522::MIFARE_Key key;

//Flame Sensor//
const int flamepin=A0;
const int buzpin=3;
const int threshold=500;// sets threshold value for flame sensor
int flamesensvalue=0;

//BlueetoothApp//
const int LED1 = 4; // Pin for LED1
const int LED2 = 5; // Pin for LED2
const int LED3 = 6; // Pin for LED3
const int LED4 = 7; // Pin for LED4

//RFID//
int ONOFFled = 8;
int j=0;

String RFIDKey1 = "D3 83 9D 00"; //assign accepted RFID Tag 1 
String RFIDKey2 = "C1 CA 0D 19"; //assign accepted RFID Tag 2

void setup() {
  Serial.begin(9600);
  SPI.begin();
  rfid.PCD_Init();
  pinMode(ONOFFled, OUTPUT);
  pinMode(flamepin,INPUT);
  pinMode(buzpin,OUTPUT);
  pinMode(LED1, OUTPUT); // Set LED1 as an output
  pinMode(LED2, OUTPUT); // Set LED2 as an output
  pinMode(LED3, OUTPUT); // Set LED3 as an output
  pinMode(LED4, OUTPUT); // Set LED4 as an output

}

void loop()
{
  {
  if (Serial.available() > 0) { // Check if data is available
    char data = Serial.read(); // Read the incoming data

    if (data == '1') { // If data is '1', turn on the LEDs
      digitalWrite(LED1, HIGH);
    } 
    else if (data == '0') { // If data is '0', turn off the LEDs
      digitalWrite(LED1, LOW);
    }

  if (data == '3') { // If data is '1', turn on the LEDs
      digitalWrite(LED2, HIGH);
    }
    else if (data == '2') { // If data is '0', turn off the LEDs
      digitalWrite(LED2, LOW);
    }

  if (data == '5') { // If data is '1', turn on the LEDs
      digitalWrite(LED3, HIGH);
    }
    else if (data == '4') { // If data is '0', turn off the LEDs
      digitalWrite(LED3, LOW);
    }

  if (data == '7') { // If data is '1', turn on the LEDs
      digitalWrite(LED4, HIGH);

    } else if (data == '6') { // If data is '0', turn off the LED
      digitalWrite(LED4, LOW);
    }
  }
}
flamesensvalue=analogRead(flamepin); // reads analog data from flame sensor
Serial.println(flamesensvalue);
if (flamesensvalue<=threshold) { // compares reading from flame sensor with the threshold value
tone(buzpin,100);
delay(100); //stops program for 1 second
}
else{
noTone(buzpin);
}
{
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial())
    return;

  // Serial.print(F("PICC type: "));
  MFRC522::PICC_Type piccType = rfid.PICC_GetType(rfid.uid.sak);
  // Serial.println(rfid.PICC_GetTypeName(piccType));

  // Check is the PICC of Classic MIFARE type
  if (piccType != MFRC522::PICC_TYPE_MIFARE_MINI &&
    piccType != MFRC522::PICC_TYPE_MIFARE_1K &&
    piccType != MFRC522::PICC_TYPE_MIFARE_4K) {
    Serial.println(F("Your tag is not of type MIFARE Classic."));
    return;
  }

  String strID = "";
  for (byte i = 0; i < 4; i++) {
    strID +=
    (rfid.uid.uidByte[i] < 0x10 ? "0" : "") +
    String(rfid.uid.uidByte[i], HEX) +
    (i!=3 ? ":" : "");
  }
  strID.toUpperCase();

  Serial.print("Tap card key: ");
  Serial.println(strID);

  //check RFID keys
  if(strID.indexOf(RFIDKey1)>=0 or strID.indexOf(RFIDKey2)>=0){
    
    if(j==1){j=0;}
    if(j==0){
      digitalWrite(ONOFFled, HIGH);
      digitalWrite(LED1, HIGH);
      }

    if(j==1){
    
      digitalWrite(ONOFFled, LOW);
      digitalWrite(LED1, LOW);
      }  
      j++;
    }
    else{

      digitalWrite(ONOFFled, LOW);
      digitalWrite(LED1, LOW);
    }

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}
}
