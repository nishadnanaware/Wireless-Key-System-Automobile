//Viral Science  www.youtube.com/c/viralscience
//Arduino Flame Sensor
const int buzzerPin = 2;
const int flamePin = 3;
int Flame = HIGH;

void setup() 
{
  pinMode(buzzerPin, OUTPUT);
  pinMode(flamePin, INPUT);
  Serial.begin(9600);
}

void loop() 
{
  Flame = digitalRead(flamePin);
  if (Flame== LOW)
  {
    digitalWrite(buzzerPin, HIGH);

  }
  else
  {
    digitalWrite(buzzerPin, LOW);
 
  }
}
